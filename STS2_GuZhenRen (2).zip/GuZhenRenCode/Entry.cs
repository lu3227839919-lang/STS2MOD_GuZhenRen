using System.Reflection;
using MegaCrit.Sts2.Core.Logging;
using MegaCrit.Sts2.Core.Modding;
using STS2RitsuLib;
using STS2RitsuLib.Interop;
using Logger = MegaCrit.Sts2.Core.Logging.Logger;
using GuZhenRen.Patches;
using GuZhenRen.Cards;
using GuZhenRen.Aperture;

namespace GuZhenRen;

/// <summary>
/// 蛊真人模组的初始化入口。
/// </summary>
[ModInitializer(nameof(Initialize))]
public partial class Entry
{
    /// <summary>
    /// 模组的稳定 ID。
    ///
    /// 必须与 GuZhenRen.json 中的 id 保持一致。
    /// </summary>
    public const string ModId = "GuZhenRen";

    /// <summary>
    /// Godot PCK 中的模组资源根路径。
    ///
    /// 该路径与 C# 命名空间无关。
    /// </summary>
    public const string ResPath =
        $"res://{ModId}";

    /// <summary>
    /// 当前模组使用的日志记录器。
    /// </summary>
    public static Logger Logger { get; } =
        new(ModId, LogType.Generic);

    private static readonly object InitializationLock =
        new();

    /// <summary>
    /// 内容发现注册成功后保持为 true。
    ///
    /// Harmony 补丁失败时可以回滚并重试，但 RitsuLib 的程序集注册
    /// 没有与 Harmony 相同的统一撤销接口，因此重试时不重复注册内容。
    /// </summary>
    private static bool _contentRegistered;

    /// <summary>
    /// 只有全部内容和补丁均成功后才设置为 true。
    /// </summary>
    private static bool _initialized;

    /// <summary>
    /// 初始化模组内容。
    /// </summary>
    public static void Initialize()
    {
        lock (InitializationLock)
        {
            if (_initialized)
            {
                return;
            }

            try
            {
                Assembly assembly =
                    Assembly.GetExecutingAssembly();

                if (!_contentRegistered)
                {
                    /*
                     * 先按 RitsuLib 官方初始化顺序注册当前程序集，
                     * 供 CLR 注解类型发现使用。
                     */
                    ModTypeDiscoveryHub.RegisterModAssembly(
                        ModId,
                        assembly
                    );

                    /*
                     * 注册 PCK 场景中挂载的 Godot C# 脚本类型。
                     */
                    RitsuLibFramework.EnsureGodotScriptsRegistered(
                        assembly,
                        Logger
                    );

                    _contentRegistered = true;
                }

                ApertureSystem.Initialize();
                LocalizationCompatibilityPatch.Initialize();
                DeckCardSelectionManualConfirmationPatch.Initialize();
                StartingDeckGuRankPatch.Initialize();
                GuRestSiteMultiUsePatch.Initialize();
                NCardXuYingEnergyIconPatch.Initialize();
                MuDaoHealPatch.Initialize();
                GuRankRewardPatch.Initialize();
                CardUniquenessPatch.Initialize();
                MerchantInventoryCompatibilityPatch.Initialize();
                ShaZhaoTuiYanPatch.Initialize();

                _initialized = true;
                TryLog(
                    "GuZhenRen Mod 初始化完成。"
                );
            }
            catch (Exception exception)
            {
                _initialized = false;
                RollbackHarmonyPatches();

                TryLog(
                    "GuZhenRen Mod 初始化失败，已回滚本次 Harmony 补丁；" +
                    $"下次调用可重试。{exception}"
                );

                throw;
            }
        }
    }

    /// <summary>
    /// 按安装顺序的逆序撤销补丁，并重置各补丁类的初始化状态。
    /// </summary>
    private static void RollbackHarmonyPatches()
    {
        TryRollback(
            nameof(ShaZhaoTuiYanPatch),
            ShaZhaoTuiYanPatch.Uninitialize
        );
        TryRollback(
            nameof(MerchantInventoryCompatibilityPatch),
            MerchantInventoryCompatibilityPatch.Uninitialize
        );
        TryRollback(
            nameof(CardUniquenessPatch),
            CardUniquenessPatch.Uninitialize
        );
        TryRollback(
            nameof(GuRankRewardPatch),
            GuRankRewardPatch.Uninitialize
        );
        TryRollback(
            nameof(MuDaoHealPatch),
            MuDaoHealPatch.Uninitialize
        );
        TryRollback(
            nameof(NCardXuYingEnergyIconPatch),
            NCardXuYingEnergyIconPatch.Uninitialize
        );
        TryRollback(
            nameof(GuRestSiteMultiUsePatch),
            GuRestSiteMultiUsePatch.Uninitialize
        );
        TryRollback(
            nameof(StartingDeckGuRankPatch),
            StartingDeckGuRankPatch.Uninitialize
        );
        TryRollback(
            nameof(DeckCardSelectionManualConfirmationPatch),
            DeckCardSelectionManualConfirmationPatch.Uninitialize
        );
        TryRollback(
            nameof(LocalizationCompatibilityPatch),
            LocalizationCompatibilityPatch.Uninitialize
        );
        TryRollback(
            nameof(ApertureSystem),
            ApertureSystem.Uninitialize
        );
    }

    /// <summary>
    /// 回滚必须是尽力而为：某一组补丁撤销失败时，继续撤销其余组，
    /// 并且不能用回滚异常覆盖最初的初始化异常。
    /// </summary>
    private static void TryRollback(
        string patchName,
        Action uninitialize
    )
    {
        try
        {
            uninitialize();
        }
        catch (Exception exception)
        {
            TryLog(
                $"回滚 {patchName} 失败：{exception}"
            );
        }
    }

    /// <summary>
    /// 日志失败不能改变初始化或回滚结果。
    /// </summary>
    private static void TryLog(string message)
    {
        try
        {
            Logger.Info(message);
        }
        catch
        {
            // 保留真正的初始化/回滚结果。
        }
    }
}
