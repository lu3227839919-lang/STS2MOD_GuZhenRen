# GuZhenRen 0.4.13

## 修复：高转蛊虫进入战斗后回退一转

- 修复通过控制台、奖励、升炼或读档获得的高转蛊虫，在永久牌组中显示正确，但进入战斗后回退为一转的问题。
- 蛊虫转数现在同时写入普通实例字段与 RitsuLib `SavedAttachedState`：普通字段负责 `ToMutable/MutableClone` 克隆，附加状态负责存档、读档和多人快照。
- `Player.PopulateCombatState` 现在会在战斗牌组创建前记录永久牌组转数，并在战斗实例生成后按卡牌 ID、升级状态和重复顺序进行二次校准。
- 高转卡牌成功校准时会输出 `[蛊虫转数]` 日志，便于确认九转实例没有丢失。

## 验证方式

```text
card GU_ZHEN_REN_CARD_XIAO_GUANG_GU rank=9
进入下一场战斗
```

日志应出现类似：

```text
[蛊虫转数] 战斗初始化已校验 6 张卡牌，修正 0 张。 高转卡牌：CARD.GU_ZHEN_REN_CARD_XIAO_GUANG_GU=9转。
```
