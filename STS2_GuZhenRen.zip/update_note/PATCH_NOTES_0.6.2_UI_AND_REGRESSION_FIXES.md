# 0.6.2：关键词视野与历史错误修复

- 自定义关键词说明仅在牌堆/永久牌组查看界面显示。
- 卡面描述继续使用 `ModKeywordCardDescriptionPlacement.None`。
- 游戏本体的消耗、保留等提示不受过滤。
- 仙元牌改为由当前 `CombatState.CreateCard` 创建，修复余额归零时无法进入消耗堆。
- 奖励满容量检查不再读取 canonical 候选牌的 `Owner`。
- `GetPossibleCards` 的蛊虫奖励过滤只在真正的卡牌奖励生成中启用，不再影响攻击药水等临时生成。
- 0.110.1 的 `CardCmd.Exhaust` 继续通过动态兼容层调用，找不到重载时不会阻止 DLL 初始化。
