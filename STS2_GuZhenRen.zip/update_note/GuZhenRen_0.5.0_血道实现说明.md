# GuZhenRen 0.5.0 血道实现说明

## 1. 实装范围

本版本在 0.4.17 基础上加入第一套完整血道内容：

### 普通蛊

| 蛊虫 | 定位 | 独立使用方式 |
| --- | --- | --- |
| 血气蛊 | 基础寄生 | 自动支付1血元；不足时失去2生命代付 |
| 血月蛊 | 群体寄生 | 血元不足2点使用免费残月档；达到2点自动支付并触发完整档 |
| 血池蛊 | 血元生产 | 获得血元，溢出转化为格挡 |
| 血皮蛊 | 防御 | 获得基础格挡；有血元时自动支付1点强化 |
| 血颅蛊 | 遗骸转化与成长 | 无遗骸仍能获得格挡；有遗骸时获得血颅或满层治疗 |
| 刀翅血蝠蛊 | 衍生牌、多段攻击 | 无遗骸生成基础血蝠；有两张遗骸时可选择生成血蝠群 |

### 合练蛊

| 合练蛊 | 配方 | 最低材料转数 | 结果转数 |
| --- | --- | ---: | --- |
| 血胎蛊 | 血气蛊＋血月蛊 | 3 | 最低材料转数＋1 |
| 血蝠王蛊 | 血颅蛊＋刀翅血蝠蛊 | 4 | 最低材料转数＋1 |
| 血河甲蛊 | 血池蛊＋血皮蛊 | 3 | 最低材料转数＋1 |

结果最高九转。合练继续沿用现有系统：材料被消耗，结果只占一个蛊虫位置。

### 杀招

| 杀招 | 配方 | 作用 |
| --- | --- | --- |
| 血漂流 | 血月蛊＋刀翅血蝠蛊，顺序不限 | 沿敌群移动并消耗流血，最后汇聚到指定终点 |
| 万骸归潮 | 血颅蛊＋血蝠王蛊，顺序不限 | 消耗至多3张遗骸，形成全场总伤害池并获得格挡 |
| 血月祭 | 血胎蛊，或血月蛊 | 不打出宿主，直接触发并剥离一份寄生 |

## 2. 血道公共资源

### 血元

- 上限12。
- 血气蛊固定消耗1点；没有血元时自动失去2点生命代付，且不能致死。
- 血月蛊拥有自动双档：0～1血元触发免费残月档；2点以上自动消耗2点并触发完整档。
- 血月蛊不允许生命代付，也不会消耗仅有的1点血元。
- 固定血元费用不再弹出支付确认界面。

### 遗骸

```text
0费状态牌
保留
获得2点血元
消耗
```

只有未结算的血道寄生宿主完成合法击杀时才会取骸：

- 每名主要敌人最多产生1张；
- 每次 CardPlay 最多产生2张；
- 非主要敌人、流血结算、血印、普通非寄生攻击和血蝠击杀不产生遗骸；
- 手牌已满时进入弃牌堆；
- 遗骸不能被寄生。

遗骸可以主动使用，也可以被血颅蛊、刀翅血蝠蛊、血蝠王蛊和万骸归潮消耗。

### 血颅

血颅是玩家 Buff，最多3层。每层：

- 血气寄生额外增加2点伤害或格挡；
- 血月寄生总伤害池增加4点；
- 刀翅血蝠类卡牌每段伤害增加1点；
- 血皮、血河甲等对应防御增加2点格挡。

血颅不提高血元、遗骸、流血或血印产量。血颅蛊在3层后继续吸收遗骸，每张改为恢复3点生命。

## 3. 寄生结算

寄生通过 `SavedAttachedState<CardModel, ...>` 保存到当前战斗的卡牌实例。

- 寄生只允许附着在可正常生成的非蛊虫攻击、技能或能力牌上；血道衍生牌、状态牌、杀招和其他蛊虫不能作为宿主。
- 宿主的 Replay 序列全部完成后，寄生只触发一次。
- 触发后寄生立即清除，血寄层数同步减少。
- 群体寄生伤害、流血和血印全部按全场总额度进行确定性分配，不会随敌人数复制收益。
- 群体攻击宿主的血气、血胎附加效果也按全场总额度分配。

目前通过玩家身上的“血寄”Buff显示尚未结算的寄生数量；尚未制作单张宿主卡牌上的专属寄生角标。

## 4. 血蝠衍生牌

- 刀翅血蝠：1费单体多段攻击；目标原本流血时增加1段；不追击。
- 刀翅血蝠群：2费多段攻击；基础比单只多2段；击杀后把剩余段数转移给生命最低的敌人。
- 血蝠王：2费；根据血蝠王蛊吸收的遗骸增加段数，吸收2张后获得追击。
- 三者均为虚无、消耗牌；自身击杀不会生成遗骸。

刀翅血蝠蛊只生成一张衍生牌：拥有两张遗骸时显示基础血蝠与血蝠群两个选项；选择血蝠群后自动消耗两张遗骸，不进行二次确认。

## 5. 新增控制台卡牌 ID

```text
card GU_ZHEN_REN_CARD_XUE_CHI_GU rank=9
card GU_ZHEN_REN_CARD_XUE_PI_GU rank=9
card GU_ZHEN_REN_CARD_XUE_LU_GU rank=9
card GU_ZHEN_REN_CARD_DAO_CHI_XUE_FU_GU rank=9

card GU_ZHEN_REN_CARD_XUE_TAI_GU rank=9
card GU_ZHEN_REN_CARD_XUE_FU_WANG_GU rank=9
card GU_ZHEN_REN_CARD_XUE_HE_JIA_GU rank=9

card GU_ZHEN_REN_CARD_YI_HAI
card GU_ZHEN_REN_CARD_DAO_CHI_XUE_FU rank=9
card GU_ZHEN_REN_CARD_DAO_CHI_XUE_FU_QUN rank=9
card GU_ZHEN_REN_CARD_XUE_FU_WANG rank=9

card GU_ZHEN_REN_CARD_XUE_PIAO_LIU rank=9
card GU_ZHEN_REN_CARD_WAN_HAI_GUI_CHAO rank=9
card GU_ZHEN_REN_CARD_XUE_YUE_JI rank=9
```

合练蛊通常应通过篝火配方获得；控制台命令主要用于功能测试。

## 6. 新增卡图文件

源码包没有附带以下新卡图。PCK 导出和游戏加载时会使用现有回退资源，并在日志中报告缺失：

```text
GuZhenRen/images/cards/XueChiGu.png
GuZhenRen/images/cards/XuePiGu.png
GuZhenRen/images/cards/XueLuGu.png
GuZhenRen/images/cards/DaoChiXueFuGu.png
GuZhenRen/images/cards/YiHai.png
GuZhenRen/images/cards/DaoChiXueFu.png
GuZhenRen/images/cards/DaoChiXueFuQun.png
GuZhenRen/images/cards/XueFuWang.png
GuZhenRen/images/cards/XueTaiGu.png
GuZhenRen/images/cards/XueFuWangGu.png
GuZhenRen/images/cards/XueHeJiaGu.png
GuZhenRen/images/cards/XuePiaoLiu.png
GuZhenRen/images/cards/WanHaiGuiChao.png
GuZhenRen/images/cards/XueYueJi.png
```

血颅、血寄和血河余甲暂时复用已有 Power 图标，因此不强制新增 Power 图片。

## 7. 回归测试重点

1. 血气蛊在0血元时失去2生命，并确保2生命或以下不能催动。
2. 血月蛊在0、1、2血元下分别验证残月、残月、完整血月档。
3. Replay 宿主只触发一次寄生、只取骸一次。
4. 群体寄生一次最多获得2张遗骸。
5. 遗骸主动使用获得2血元。
6. 血颅0→3层与满层后的溢出治疗。
7. 刀翅血蝠蛊有2张遗骸时能选择保留遗骸或生成血蝠群。
8. 血蝠群击杀后追击，且不会产生新遗骸。
9. 三条合练配方、结果转数和材料消耗。
10. 三式杀招的推演、目标选择、多人确定性和存档恢复。
