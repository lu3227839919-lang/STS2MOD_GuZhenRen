

## 图片路径

新增牌均使用同名图片：

- `GuZhenRen/images/LiuGuangGu.png`
- `GuZhenRen/images/LiuGuang.png`
- `GuZhenRen/images/LiuHui.png`
- `GuZhenRen/images/BaiHong.png`
- `GuZhenRen/images/BaiHongGuanRi.png`
- `GuZhenRen/images/JingYueFanZhao.png`

缺失时继续由 `CardImageCatalog` 输出警告。
