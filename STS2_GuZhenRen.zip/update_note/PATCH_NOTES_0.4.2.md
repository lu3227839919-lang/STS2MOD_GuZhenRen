# 0.4.2 卡牌图片路径统一

## 图片目录

所有具体卡牌统一使用与 C# 运行时类型同名的 PNG：

```text
res://GuZhenRen/images/{CardTypeName}.png
```

开发机对应目录：

```text
E:\work\csharp\StS2_Mods\STS2_GuZhenRen\GuZhenRen\images\{CardTypeName}.png
```

示例：

```text
YueGuangGu -> GuZhenRen/images/YueGuangGu.png
YueRen -> GuZhenRen/images/YueRen.png
JingHuiGu -> GuZhenRen/images/JingHuiGu.png
YueNiChang -> GuZhenRen/images/YueNiChang.png
```

## 缺图警告

- 新增 `CardImageCatalog`，统一生成卡图路径。
- 初始化时扫描程序集内所有具体 `CardModel`。
- 缺图时逐张输出 `[卡图缺失]` 警告，同时显示 Godot 路径与本地绝对路径。
- 扫描完成后输出卡牌总数与缺图数量汇总。
- 不再静默复用月光蛊、玉皮蛊、小光蛊或其他卡牌的图片。
- 即使缺图，`AssetProfile` 仍保留预期同名路径，方便 Godot/RitsuLib 继续提供资源诊断。

## 文档

- 更新《蛊虫卡牌大全》，新增所有具体卡牌的图片路径索引。
- 新增 `CARD_IMAGE_AUDIT_0.4.2.md`。
- 新增 `GuZhenRen/images/CARD_IMAGE_NAMES.txt`，列出全部预期 PNG 文件名。

## 当前上传包审计

上传源码包未携带 PNG，因此静态审计识别到的 45 张具体卡牌全部标记为缺图。你本地放入同名 PNG 后，运行时检查会按实际资源状态输出结果。
