# 0.6.1：全部蛊虫关键词与 0.110.1 初始化修复

## 初始化修复

游戏 0.110.1 修改了 `CardCmd.Exhaust` 的运行时参数签名。

旧代码在初始化时硬查找：

```csharp
CardCmd.Exhaust(PlayerChoiceContext, CardModel)
```

找不到就抛出 `MissingMethodException`，导致整个模组初始化回滚。

0.6.1 改为：

- 动态枚举当前游戏实际存在的 `CardCmd.Exhaust` 重载；
- 只挂载返回 `Task` 且包含 `CardModel` 参数的方法；
- 使用 `object[] __args` 读取不同版本的参数；
- 找不到重载时记录警告并跳过，不再阻止模组初始化；
- 模组内部所有主动消耗调用统一通过 `CardExhaustCompat.ExhaustAsync`，
  避免运行到相关卡牌效果时再次触发缺失方法。

## 全部蛊虫关键词提示

所有蛊虫统一显示：

- 蛊虫；
- 当前一至九转；
- 催动；
- 恢复；
- 元气。

六转以上额外显示：

- 仙蛊；
- 仙元。

每张蛊虫还会根据自身机制显示相关术语，如光辉、折光、照破、
聚光、耀化、血元、血寄、月相、遗骸、血颅、流血和血印等。

所有自定义关键词均设置为：

```csharp
CardDescriptionPlacement =
    ModKeywordCardDescriptionPlacement.None
```

关键词解释不会自动插入卡面正文，只在卡牌附近的悬浮提示框中显示。

## 回归检查

1. 游戏 0.110.1 启动时日志出现“GuZhenRen Mod 初始化完成”。
2. 不再出现 `CardCmd.Exhaust(PlayerChoiceContext, CardModel) was not found`。
3. 悬停任意蛊虫，都能看到蛊虫、转数、催动、恢复、元气提示。
4. 六转以上蛊虫能看到仙蛊和仙元提示。
5. 合练蛊能看到合练提示。
6. 血寄宿主被直接消耗、虚无消耗或卡牌效果消耗时仍能触发破胎。
