# GuZhenRen 0.4.17 — 升炼多选与手动确认修复

## 升炼选择

- 每次升炼固定允许选择 0 至 2 只符合条件的蛊虫。
- 不再要求牌组先拥有六转蛊虫才能选择第二只。
- 选择第一只或第二只蛊虫后，界面不会自动进入“是否升炼”确认页。
- 玩家必须主动点击确认按钮提交选择。
- 选择 0 只并确认等同于取消，不消耗本次休息点升炼机会。
- 选择 1 至 2 只时，每只蛊虫各提升一转。

## 缺失卡图

当前日志报告以下 5 张卡牌缺少同名 PNG：

- `GuangBiao.png`
- `CanMang.png`
- `NingJingHui.png`
- `YuGuangYi.png`
- `ZheGuang.png`

目标目录：

```text
res://GuZhenRen/images/cards/
```
