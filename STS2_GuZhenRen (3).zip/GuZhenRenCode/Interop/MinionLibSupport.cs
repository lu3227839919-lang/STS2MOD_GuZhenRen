using System.Reflection;

namespace GuZhenRen.Interop;

/// <summary>
/// GuZhenRen 与 MinionLib 的最小集成入口。
///
/// 引用 MainFile 类型可让编译器和 NuGet 恢复阶段确认 MinionLib API 可用，
/// 同时在运行时读取实际加载的程序集版本。MinionLib 自己带有
/// ModInitializer，因此这里绝不能再次调用 MinionLib.MainFile.Initialize()。
/// </summary>
internal static class MinionLibSupport
{
    private static bool _initialized;

    public static string RuntimeVersion { get; private set; } =
        "unknown";

    public static void Initialize()
    {
        if (_initialized)
        {
            return;
        }

        Assembly minionLibAssembly =
            typeof(MinionLib.MainFile).Assembly;

        RuntimeVersion =
            minionLibAssembly.GetName().Version?.ToString()
            ?? "unknown";

        _initialized = true;
    }
}
