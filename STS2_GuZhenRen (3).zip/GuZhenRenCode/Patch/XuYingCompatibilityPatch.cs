using System.Reflection;

using Godot;
using HarmonyLib;

using GuZhenRen.Cards;

using MegaCrit.Sts2.Core.Entities.UI;
using MegaCrit.Sts2.Core.Models;
using MegaCrit.Sts2.Core.Nodes.Cards;

namespace GuZhenRen.Patches;

/// <summary>
/// 集中处理虚影卡的隐藏玩法规则：回合结束时保留，但不公开 Retain
/// 关键词；卡面可见时隐藏普通能量图标。
/// </summary>
internal static class XuYingCompatibilityPatch
{
    private const string HarmonyId =
        Entry.ModId + ".XuYingCompatibility";

    private static FieldInfo? _energyIconField;
    private static bool _initialized;

    internal static void Initialize()
    {
        if (_initialized)
        {
            return;
        }

        MethodInfo shouldRetainGetter =
            AccessTools.PropertyGetter(
                typeof(CardModel),
                nameof(CardModel.ShouldRetainThisTurn)
            )
            ?? throw new MissingMethodException(
                typeof(CardModel).FullName,
                "get_" + nameof(CardModel.ShouldRetainThisTurn)
            );

        MethodInfo updateEnergyCostVisuals =
            AccessTools.DeclaredMethod(
                typeof(NCard),
                "UpdateEnergyCostVisuals"
            )
            ?? throw new MissingMethodException(
                typeof(NCard).FullName,
                "UpdateEnergyCostVisuals"
            );

        _energyIconField =
            AccessTools.Field(typeof(NCard), "_energyIcon")
            ?? throw new MissingFieldException(
                typeof(NCard).FullName,
                "_energyIcon"
            );

        Harmony harmony = new(HarmonyId);

        try
        {
            harmony.Patch(
                shouldRetainGetter,
                postfix: new HarmonyMethod(
                    typeof(XuYingCompatibilityPatch),
                    nameof(ShouldRetainThisTurnPostfix)
                )
            );
            harmony.Patch(
                updateEnergyCostVisuals,
                postfix: new HarmonyMethod(
                    typeof(XuYingCompatibilityPatch),
                    nameof(UpdateEnergyCostVisualsPostfix)
                )
            );

            _initialized = true;
        }
        catch
        {
            harmony.UnpatchAll(HarmonyId);
            _energyIconField = null;
            throw;
        }
    }

    internal static void Uninitialize()
    {
        try
        {
            new Harmony(HarmonyId).UnpatchAll(HarmonyId);
        }
        finally
        {
            _energyIconField = null;
            _initialized = false;
        }
    }

    private static void ShouldRetainThisTurnPostfix(
        CardModel __instance,
        ref bool __result
    )
    {
        if (__instance is AbstractXuYingCard)
        {
            __result = true;
        }
    }

    private static void UpdateEnergyCostVisualsPostfix(
        NCard __instance
    )
    {
        // 未解锁/未见卡应保持原版问号能量图标，避免通过图标差异泄漏卡种。
        if (__instance.Visibility != ModelVisibility.Visible ||
            __instance.Model is not AbstractXuYingCard)
        {
            return;
        }

        if (_energyIconField?.GetValue(__instance)
            is TextureRect energyIcon)
        {
            energyIcon.Visible = false;
        }
    }
}
