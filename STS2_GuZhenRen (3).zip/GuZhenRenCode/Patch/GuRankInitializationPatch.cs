using System.Reflection;
using System.Runtime.CompilerServices;

using HarmonyLib;

using GuZhenRen.Cards;
using GuZhenRen.Characters;

using MegaCrit.Sts2.Core.Entities.Cards;
using MegaCrit.Sts2.Core.Entities.Players;
using MegaCrit.Sts2.Core.Models;
using MegaCrit.Sts2.Core.Random;
using MegaCrit.Sts2.Core.Rewards;

using STS2RitsuLib;

namespace GuZhenRen.Patches;

/// <summary>
/// 统一处理蛊卡首次赋阶：初始牌组固定至少一转，卡牌奖励按奖励流随机赋阶。
/// </summary>
internal static class GuRankInitializationPatch
{
    private const string HarmonyId =
        Entry.ModId + ".GuRankInitialization";
    private const string RewardRngStreamId =
        "reward/gu_rank";

    private static readonly ConditionalWeakTable<
        CardReward,
        RewardGenerationState
    > RewardGenerationStates = new();

    private static bool _initialized;

    internal static void Initialize()
    {
        if (_initialized)
        {
            return;
        }

        MethodInfo populateStartingDeck =
            AccessTools.DeclaredMethod(
                typeof(Player),
                "PopulateStartingDeck"
            )
            ?? throw new MissingMethodException(
                "初始牌组赋阶所需的 Player.PopulateStartingDeck 不存在。"
            );

        MethodInfo rewardPopulate =
            AccessTools.Method(
                typeof(CardReward),
                nameof(CardReward.Populate)
            )
            ?? throw new MissingMethodException(
                "奖励赋阶所需的 CardReward.Populate 不存在。"
            );

        Harmony harmony = new(HarmonyId);

        try
        {
            harmony.Patch(
                populateStartingDeck,
                postfix: new HarmonyMethod(
                    typeof(GuRankInitializationPatch),
                    nameof(PopulateStartingDeckPostfix)
                )
            );
            harmony.Patch(
                rewardPopulate,
                postfix: new HarmonyMethod(
                    typeof(GuRankInitializationPatch),
                    nameof(CardRewardPopulatePostfix)
                )
            );

            _initialized = true;
        }
        catch
        {
            harmony.UnpatchAll(HarmonyId);
            throw;
        }
    }

    internal static void Uninitialize()
    {
        try
        {
            new Harmony(HarmonyId).UnpatchAll(HarmonyId);
        }
        finally
        {
            _initialized = false;
        }
    }

    private static void PopulateStartingDeckPostfix(
        Player __instance
    )
    {
        if (__instance.Character is not GuZhenRenCharacter)
        {
            return;
        }

        int updatedCount = 0;

        foreach (AbstractGuZhenRenCard card in __instance
                     .Deck
                     .Cards
                     .OfType<AbstractGuZhenRenCard>())
        {
            if (card.EnsureMinimumGuRank())
            {
                updatedCount++;
            }
        }

        if (updatedCount > 0)
        {
            Entry.Logger.Info(
                $"已将蛊真人初始牌组中的 {updatedCount} 张蛊虫牌设为一转。"
            );
        }
    }

    private static void CardRewardPopulatePostfix(
        CardReward __instance
    )
    {
        CardModel[] cards = __instance.Cards.ToArray();
        RewardGenerationState state =
            RewardGenerationStates.GetValue(
                __instance,
                static _ => new RewardGenerationState()
            );

        lock (state)
        {
            if (state.IsSameGeneration(cards))
            {
                return;
            }

            Player player = __instance.Player;
            Rng rng = RitsuLibFramework.GetModPlayerRng(
                player,
                Entry.ModId,
                RewardRngStreamId
            );

            AssignRandomRanks(cards, rng, player);
            state.SetGeneration(cards);
        }
    }

    private static void AssignRandomRanks(
        IEnumerable<CardModel> cards,
        Rng rng,
        Player player
    )
    {
        foreach (CardModel card in cards)
        {
            // 每个奖励位置消费一个父流种子，确保不同客户端的后续位置对齐。
            uint cardSeed = rng.NextUnsignedInt();

            if (card is not AbstractGuZhenRenCard guCard)
            {
                continue;
            }

            int maximumRewardRank = guCard.MaxGuRank;

            if (GuZhenRenCardRules.HasSameXianGu(
                    player.RunState,
                    card
                ))
            {
                maximumRewardRank = Math.Min(
                    maximumRewardRank,
                    GuZhenRenCardRules.XianGuRank - 1
                );
            }

            bool assigned = guCard.TryAssignRandomGuRankOnReward(
                new Rng(cardSeed),
                player.RunState.TotalFloor,
                maxRank: maximumRewardRank
            );

            if (assigned)
            {
                GuZhenRenCardRules.RegisterXianGuClaim(
                    guCard,
                    player.RunState.TotalFloor
                );
            }
        }
    }

    private sealed class RewardGenerationState
    {
        private CardModel[] _cards = [];

        internal bool IsSameGeneration(
            IReadOnlyList<CardModel> cards
        )
        {
            if (_cards.Length != cards.Count)
            {
                return false;
            }

            for (int index = 0; index < cards.Count; index++)
            {
                if (!ReferenceEquals(_cards[index], cards[index]))
                {
                    return false;
                }
            }

            return true;
        }

        internal void SetGeneration(
            CardModel[] cards
        )
        {
            _cards = cards;
        }
    }
}
