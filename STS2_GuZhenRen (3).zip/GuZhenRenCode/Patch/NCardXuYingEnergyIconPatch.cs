using System;
using System.Reflection;

using Godot;
using HarmonyLib;

using MegaCrit.Sts2.Core.Nodes.Cards;

namespace GuZhenRen.Patches;

/// <summary>
/// 隐藏虚影卡的普通能量图标。
///
/// 只隐藏 NCard 的普通 EnergyIcon；
/// 不处理不可使用覆盖图标或星星费用。
/// </summary>
internal static class NCardXuYingEnergyIconPatch
{
    private const string HarmonyId =
        Entry.ModId + ".NCardXuYingEnergyIcon";

    private static bool _initialized;

    private static FieldInfo? _energyIconField;

    /// <summary>
    /// 在 Entry.Initialize() 中调用一次。
    /// </summary>
    internal static void Initialize()
    {
        if (_initialized)
        {
            return;
        }

        MethodInfo original =
            AccessTools.Method(
                typeof(NCard),
                "UpdateEnergyCostVisuals"
            )
            ?? throw new MissingMethodException(
                typeof(NCard).FullName,
                "UpdateEnergyCostVisuals"
            );

        _energyIconField =
            AccessTools.Field(
                typeof(NCard),
                "_energyIcon"
            )
            ?? throw new MissingFieldException(
                typeof(NCard).FullName,
                "_energyIcon"
            );

        MethodInfo postfix =
            AccessTools.Method(
                typeof(NCardXuYingEnergyIconPatch),
                nameof(Postfix)
            )
            ?? throw new MissingMethodException(
                typeof(NCardXuYingEnergyIconPatch).FullName,
                nameof(Postfix)
            );

        new Harmony(HarmonyId).Patch(
            original,
            postfix:
                new HarmonyMethod(postfix)
        );

        _initialized = true;
    }

    internal static void Uninitialize()
    {
        try
        {
            new Harmony(HarmonyId).UnpatchAll(HarmonyId);
        }
        finally
        {
            _energyIconField = null;
            _initialized = false;
        }
    }

    private static void Postfix(
        NCard __instance
    )
    {
        if (__instance.Model is not
            global::GuZhenRen.Cards.AbstractXuYingCard)
        {
            return;
        }

        if (_energyIconField?.GetValue(__instance)
            is TextureRect energyIcon)
        {
            energyIcon.Visible = false;
        }
    }
}
